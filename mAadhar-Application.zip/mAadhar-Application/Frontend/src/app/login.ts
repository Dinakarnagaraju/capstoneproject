export class Login {
    constructor(public emailid:string,
        public password:string,
        public typeOfUser:string,
        public name:string,
        public id:number,
        public address:string,
        public phone:number,
        public dob:string
        ){}
}
